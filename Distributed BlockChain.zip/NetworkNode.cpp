#include "NetworkNode.h"
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <iostream>
#include <sstream>
#include <random>

// NetworkMessage implementation
std::string NetworkMessage::serialize() const {
    std::stringstream ss;
    ss << static_cast<int>(type) << "|" << sender << "|" << data;
    return ss.str();
}

NetworkMessage NetworkMessage::deserialize(const std::string& serialized) {
    std::vector<std::string> parts;
    boost::split(parts, serialized, boost::is_any_of("|"));
    
    if (parts.size() < 3) {
        throw std::runtime_error("Invalid message format");
    }
    
    MessageType type = static_cast<MessageType>(std::stoi(parts[0]));
    std::string sender = parts[1];
    
    // Combine the rest of the parts as data (in case data contains the delimiter)
    std::string data;
    for (size_t i = 2; i < parts.size(); ++i) {
        if (i > 2) data += "|";
        data += parts[i];
    }
    
    return NetworkMessage(type, sender, data);
}

// Connection implementation
Connection::Connection(boost::asio::io_context& io_context, NetworkManager* manager)
    : socket_(io_context), manager_(manager) {
}

void Connection::start() {
    boost::asio::async_read(
        socket_,
        boost::asio::buffer(buffer_),
        boost::asio::transfer_at_least(1),
        boost::bind(
            &Connection::handle_read,
            shared_from_this(),
            boost::asio::placeholders::error,
            boost::asio::placeholders::bytes_transferred
        )
    );
}

void Connection::send(const NetworkMessage& message) {
    std::string serialized = message.serialize() + "\n"; // Add newline as message delimiter
    boost::asio::async_write(
        socket_,
        boost::asio::buffer(serialized),
        boost::bind(
            &Connection::handle_write,
            shared_from_this(),
            boost::asio::placeholders::error
        )
    );
}

void Connection::handle_read(const boost::system::error_code& error, size_t bytes_transferred) {
    if (!error) {
        message_buffer_.append(buffer_.data(), bytes_transferred);
        
        // Check if we have a complete message (terminated by newline)
        size_t pos = message_buffer_.find('\n');
        while (pos != std::string::npos) {
            std::string message_str = message_buffer_.substr(0, pos);
            message_buffer_.erase(0, pos + 1);
            
            try {
                NetworkMessage message = NetworkMessage::deserialize(message_str);
                manager_->handleMessage(shared_from_this(), message);
            } catch (const std::exception& e) {
                std::cerr << "Error parsing message: " << e.what() << std::endl;
            }
            
            pos = message_buffer_.find('\n');
        }
        
        // Continue reading
        boost::asio::async_read(
            socket_,
            boost::asio::buffer(buffer_),
            boost::asio::transfer_at_least(1),
            boost::bind(
                &Connection::handle_read,
                shared_from_this(),
                boost::asio::placeholders::error,
                boost::asio::placeholders::bytes_transferred
            )
        );
    } else {
        // Connection closed or error occurred
        if (error != boost::asio::error::eof) {
            std::cerr << "Error: " << error.message() << std::endl;
        }
    }
}

void Connection::handle_write(const boost::system::error_code& error) {
    if (error) {
        std::cerr << "Error writing to socket: " << error.message() << std::endl;
    }
}

// NetworkManager implementation
NetworkManager::NetworkManager(Blockchain& blockchain, const std::string& host, int port, NodeType type)
    : blockchain(blockchain),
      nodeType(type),
      host(host),
      port(port),
      acceptor(io_context, boost::asio::ip::tcp::endpoint(
          boost::asio::ip::make_address(host), port)),
      running(false) {
    
    // Generate a unique node ID
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(1000, 9999);
    nodeId = "Node_" + std::to_string(dis(gen)) + "_" + std::to_string(time(nullptr));
    
    std::cout << "Network node initialized with ID: " << nodeId << std::endl;
    std::cout << "Node type: " << (nodeType == NodeType::FULL_NODE ? "Full Node (with mining)" : "Wallet Node") << std::endl;
    std::cout << "Listening on " << host << ":" << port << std::endl;
}

NetworkManager::~NetworkManager() {
    stop();
}

void NetworkManager::start() {
    if (running) return;
    
    running = true;
    
    // Start accepting incoming connections
    startAccept();
    
    // Start the io_context in a separate thread
    service_thread = std::thread([this]() {
        try {
            io_context.run();
        } catch (const std::exception& e) {
            std::cerr << "Network error: " << e.what() << std::endl;
        }
    });
    
    std::cout << "Network services started." << std::endl;
}

void NetworkManager::stop() {
    if (!running) return;
    
    running = false;
    
    // Stop the io_context
    io_context.stop();
    
    // Wait for the service thread to finish
    if (service_thread.joinable()) {
        service_thread.join();
    }
    
    // Close all connections
    std::lock_guard<std::mutex> lock(connections_mutex);
    connections.clear();
    
    std::cout << "Network services stopped." << std::endl;
}

void NetworkManager::startAccept() {
    Connection::pointer new_connection = Connection::create(io_context, this);
    
    acceptor.async_accept(
        new_connection->socket(),
        boost::bind(
            &NetworkManager::handleAccept,
            this,
            new_connection,
            boost::asio::placeholders::error
        )
    );
}

void NetworkManager::handleAccept(Connection::pointer new_connection, const boost::system::error_code& error) {
    if (!error) {
        // Successfully accepted a new connection
        std::cout << "Accepted new connection from " 
                  << new_connection->socket().remote_endpoint().address().to_string()
                  << ":" << new_connection->socket().remote_endpoint().port() << std::endl;
        
        // Start the connection
        new_connection->start();
        
        {
            std::lock_guard<std::mutex> lock(connections_mutex);
            connections.push_back(new_connection);
        }
        
        // Send a handshake message
        std::string type_str = (nodeType == NodeType::FULL_NODE) ? "FULL_NODE" : "WALLET_NODE";
        NetworkMessage handshake(MessageType::HANDSHAKE, nodeId, type_str);
        new_connection->send(handshake);
    }
    
    // Continue accepting new connections
    startAccept();
}

bool NetworkManager::connectToPeer(const std::string& address, int peer_port) {
    try {
        boost::asio::ip::tcp::resolver resolver(io_context);
        auto endpoints = resolver.resolve(address, std::to_string(peer_port));
        
        // Create a new connection
        Connection::pointer connection = Connection::create(io_context, this);
        
        // Connect to the peer
        boost::asio::connect(connection->socket(), endpoints);
        
        std::cout << "Connected to peer at " << address << ":" << peer_port << std::endl;
        
        // Start the connection
        connection->start();
        
        {
            std::lock_guard<std::mutex> lock(connections_mutex);
            connections.push_back(connection);
        }
        
        // Send a handshake message
        std::string type_str = (nodeType == NodeType::FULL_NODE) ? "FULL_NODE" : "WALLET_NODE";
        NetworkMessage handshake(MessageType::HANDSHAKE, nodeId, type_str);
        connection->send(handshake);
        
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error connecting to peer at " << address << ":" << peer_port << ": " << e.what() << std::endl;
        return false;
    }
}

void NetworkManager::broadcastTransaction(const Transaction& transaction) {
    // Convert the transaction to a serialized string
    std::stringstream ss;
    ss << transaction.sender << "|"
       << transaction.receiver << "|"
       << transaction.amount << "|"
       << transaction.timestamp << "|"
       << transaction.hash << "|"
       << transaction.signature;
    
    std::string tx_data = ss.str();
    
    // Create a network message
    NetworkMessage msg(MessageType::TRANSACTION, nodeId, tx_data);
    
    // Broadcast to all connections
    std::lock_guard<std::mutex> lock(connections_mutex);
    for (auto& connection : connections) {
        connection->send(msg);
    }
    
    std::cout << "Broadcasted transaction to " << connections.size() << " peers." << std::endl;
}

void NetworkManager::broadcastBlock(const Block& block) {
    // Only full nodes should broadcast blocks
    if (nodeType != NodeType::FULL_NODE) {
        std::cerr << "Warning: Wallet nodes should not broadcast blocks." << std::endl;
        return;
    }
    
    // Serialize the block
    std::stringstream ss;
    ss << block.blockNumber << "|"
       << block.timestamp << "|"
       << block.previousHash << "|"
       << block.hash << "|"
       << block.nonce << "|"
       << block.difficulty << "|"
       << block.transactions.size();
    
    // Add each transaction to the serialized data
    for (const auto& tx : block.transactions) {
        ss << "|" << tx.sender << "|"
           << tx.receiver << "|"
           << tx.amount << "|"
           << tx.timestamp << "|"
           << tx.hash << "|"
           << tx.signature;
    }
    
    std::string block_data = ss.str();
    
    // Create a network message
    NetworkMessage msg(MessageType::BLOCK, nodeId, block_data);
    
    // Broadcast to all connections
    std::lock_guard<std::mutex> lock(connections_mutex);
    for (auto& connection : connections) {
        connection->send(msg);
    }
    
    std::cout << "Broadcasted block #" << block.blockNumber << " to " << connections.size() << " peers." << std::endl;
}

void NetworkManager::requestBlockchain() {
    // Create a request message
    NetworkMessage msg(MessageType::CHAIN_REQUEST, nodeId, "");
    
    // Send to all connections
    std::lock_guard<std::mutex> lock(connections_mutex);
    for (auto& connection : connections) {
        connection->send(msg);
    }
    
    std::cout << "Requested blockchain from " << connections.size() << " peers." << std::endl;
}

void NetworkManager::handleMessage(Connection::pointer connection, const NetworkMessage& message) {
    std::cout << "Received message of type " << static_cast<int>(message.type) << " from " << message.sender << std::endl;
    
    switch (message.type) {
        case MessageType::HANDSHAKE: {
            // Add the peer to our peer list
            std::string peer_address = connection->socket().remote_endpoint().address().to_string();
            int peer_port = connection->socket().remote_endpoint().port();
            
            NodeType peer_type = (message.data == "FULL_NODE") ? NodeType::FULL_NODE : NodeType::WALLET_NODE;
            
            Peer new_peer(peer_address, peer_port, peer_type, message.sender);
            
            {
                std::lock_guard<std::mutex> lock(peers_mutex);
                peers.insert(new_peer);
            }
            
            std::cout << "Handshake completed with peer " << message.sender << " at " 
                      << peer_address << ":" << peer_port << " (" 
                      << (peer_type == NodeType::FULL_NODE ? "Full Node" : "Wallet Node") << ")" << std::endl;
            
            // Send our peer list to the new peer
            std::stringstream ss;
            
            {
                std::lock_guard<std::mutex> lock(peers_mutex);
                ss << peers.size();
                
                for (const auto& peer : peers) {
                    ss << "|" << peer.address << "|" << peer.port << "|"
                       << (peer.type == NodeType::FULL_NODE ? "FULL_NODE" : "WALLET_NODE") << "|"
                       << peer.id;
                }
            }
            
            NetworkMessage peer_list_msg(MessageType::PEER_LIST, nodeId, ss.str());
            connection->send(peer_list_msg);
            break;
        }
        
        case MessageType::TRANSACTION: {
            // Parse the transaction data
            std::vector<std::string> parts;
            boost::split(parts, message.data, boost::is_any_of("|"));
            
            if (parts.size() != 6) {
                std::cerr << "Invalid transaction data format" << std::endl;
                break;
            }
            
            // Create a new transaction
            Transaction tx(parts[0], parts[1], std::stoi(parts[2]));
            tx.timestamp = std::stoul(parts[3]);
            tx.hash = parts[4];
            tx.signature = parts[5];
            
            // Validate the transaction
            if (!tx.isValid()) {
                std::cerr << "Received invalid transaction from " << message.sender << std::endl;
                break;
            }
            
            // Add to the blockchain mempool
            blockchain.addTransaction(tx);
            
            // Relay the transaction to other peers (except the sender)
            std::lock_guard<std::mutex> lock(connections_mutex);
            for (auto& conn : connections) {
                if (conn != connection) {
                    conn->send(message);
                }
            }
            
            std::cout << "Added and relayed transaction from " << tx.sender << " to " << tx.receiver << " for " << tx.amount << std::endl;
            break;
        }
        
        case MessageType::BLOCK: {
            // Parse the block data
            std::vector<std::string> parts;
            boost::split(parts, message.data, boost::is_any_of("|"));
            
            if (parts.size() < 7) {
                std::cerr << "Invalid block data format" << std::endl;
                break;
            }
            
            int blockNumber = std::stoi(parts[0]);
            time_t timestamp = std::stoul(parts[1]);
            std::string previousHash = parts[2];
            std::string hash = parts[3];
            int nonce = std::stoi(parts[4]);
            int difficulty = std::stoi(parts[5]);
            int txCount = std::stoi(parts[6]);
            
            // Check if we have at least enough data for all transactions
            size_t required_size = 7 + static_cast<size_t>(txCount) * 6;
            if (parts.size() < required_size) {
                std::cerr << "Invalid block data: missing transaction data" << std::endl;
                break;
            }
            
            // Create transactions from the data
            std::vector<Transaction> transactions;
            for (int i = 0; i < txCount; ++i) {
                int base_idx = 7 + i * 6;
                
                Transaction tx(parts[base_idx], parts[base_idx + 1], std::stoi(parts[base_idx + 2]));
                tx.timestamp = std::stoul(parts[base_idx + 3]);
                tx.hash = parts[base_idx + 4];
                tx.signature = parts[base_idx + 5];
                
                transactions.push_back(tx);
            }
            
            // Create a new block - without mining it
            Block block(blockNumber, transactions, previousHash, difficulty);
            block.timestamp = timestamp;
            block.nonce = nonce;
            block.hash = hash;
            
            // Add the block to the blockchain
            // This would typically involve validation logic
            // For simplicity, we'll add it directly
            blockchain.addBlock(transactions);
            
            // Relay the block to other peers (except the sender)
            std::lock_guard<std::mutex> lock(connections_mutex);
            for (auto& conn : connections) {
                if (conn != connection) {
                    conn->send(message);
                }
            }
            
            std::cout << "Added and relayed block #" << blockNumber << " with " << txCount << " transactions" << std::endl;
            break;
        }
        
        case MessageType::CHAIN_REQUEST: {
            // Only full nodes should respond to blockchain requests
            if (nodeType != NodeType::FULL_NODE) {
                std::cerr << "Warning: Wallet node received blockchain request but cannot respond." << std::endl;
                break;
            }
            
            // Serialize the blockchain
            std::stringstream ss;
            const std::vector<Block>& chain = blockchain.getChain();
            
            ss << chain.size();
            
            for (const auto& block : chain) {
                ss << "|" << block.blockNumber << "|"
                   << block.timestamp << "|"
                   << block.previousHash << "|"
                   << block.hash << "|"
                   << block.nonce << "|"
                   << block.difficulty << "|"
                   << block.transactions.size();
                
                for (const auto& tx : block.transactions) {
                    ss << "|" << tx.sender << "|"
                       << tx.receiver << "|"
                       << tx.amount << "|"
                       << tx.timestamp << "|"
                       << tx.hash << "|"
                       << tx.signature;
                }
            }
            
            NetworkMessage response(MessageType::CHAIN_RESPONSE, nodeId, ss.str());
            connection->send(response);
            
            std::cout << "Sent blockchain (" << chain.size() << " blocks) to " << message.sender << std::endl;
            break;
        }
        
        case MessageType::CHAIN_RESPONSE: {
            // Parse the blockchain data
            std::vector<std::string> parts;
            boost::split(parts, message.data, boost::is_any_of("|"));
            
            if (parts.size() < 1) {
                std::cerr << "Invalid blockchain data format" << std::endl;
                break;
            }
            
            int blockCount = std::stoi(parts[0]);
            std::cout << "Received blockchain with " << blockCount << " blocks from " << message.sender << std::endl;
            
            // TODO: Parse and validate the blockchain
            // For simplicity, we'll assume it's valid
            break;
        }
        
        case MessageType::PEER_LIST: {
            // Parse the peer list
            std::vector<std::string> parts;
            boost::split(parts, message.data, boost::is_any_of("|"));
            
            if (parts.size() < 1) {
                std::cerr << "Invalid peer list format" << std::endl;
                break;
            }
            
            int peerCount = std::stoi(parts[0]);
            std::cout << "Received list of " << peerCount << " peers from " << message.sender << std::endl;
            
            size_t required_size = 1 + static_cast<size_t>(peerCount) * 4;
            if (parts.size() < required_size) {
                std::cerr << "Invalid peer list: missing peer data" << std::endl;
                break;
            }
            
            for (int i = 0; i < peerCount; ++i) {
                int base_idx = 1 + i * 4;
                
                std::string peer_address = parts[base_idx];
                int peer_port = std::stoi(parts[base_idx + 1]);
                NodeType peer_type = (parts[base_idx + 2] == "FULL_NODE") ? NodeType::FULL_NODE : NodeType::WALLET_NODE;
                std::string peer_id = parts[base_idx + 3];
                
                // Don't connect to ourselves
                if (peer_address == host && peer_port == port) {
                    continue;
                }
                
                // Check if we already know this peer
                Peer new_peer(peer_address, peer_port, peer_type, peer_id);
                
                bool peer_exists = false;
                {
                    std::lock_guard<std::mutex> lock(peers_mutex);
                    peer_exists = (peers.find(new_peer) != peers.end());
                    if (!peer_exists) {
                        peers.insert(new_peer);
                    }
                }
                
                // Connect to the new peer if we don't already know it
                if (!peer_exists) {
                    connectToPeer(peer_address, peer_port);
                }
            }
            break;
        }
        
        case MessageType::PING: {
            // Respond with a PONG
            NetworkMessage pong(MessageType::PONG, nodeId, "");
            connection->send(pong);
            break;
        }
        
        case MessageType::PONG: {
            // Just log that we received a pong
            std::cout << "Received PONG from " << message.sender << std::endl;
            break;
        }
        
        default:
            std::cerr << "Unknown message type: " << static_cast<int>(message.type) << std::endl;
            break;
    }
}

std::vector<Peer> NetworkManager::getConnectedPeers() const {
    std::vector<Peer> connectedPeers;
    
    std::lock_guard<std::mutex> lock(peers_mutex);
    for (const auto& peer : peers) {
        connectedPeers.push_back(peer);
    }
    
    return connectedPeers;
} 