# Blockchain Demo

A simple implementation of a blockchain in C++ that demonstrates the core concepts of blockchain technology.

## Features

- Create transactions with sender, receiver, and amount information
- Manage wallets with private/public key pairs
- Send money between wallets and track balances
- Mine new blocks with pending transactions
- View the entire blockchain and its contents
- View transactions in the mempool
- Validate the integrity of the blockchain
- Configure mining difficulty

## Requirements

- C++11 compiler

## Building

```bash
# Compile the project
make

# Run the application
make run

# Or manually
./blockchain_demo
```

## Project Structure

- `main.cpp` - Contains the menu-driven interface for interacting with the blockchain
- `Blockchain.h/cpp` - Implements the blockchain data structure and related functionality
- `Block.h/cpp` - Implements a single block in the blockchain with mining capability
- `Transaction.h/cpp` - Implements a transaction model with sender, receiver, and amount
- `wallet.h/cpp` - Implements a wallet system for managing keys and balances
- `sha.h/cpp` - Provides hash functionality for the blockchain

## Usage

1. When you first run the application, you will be prompted to set the mining difficulty (1-6 recommended)
2. Use the menu to interact with the blockchain:
   - Create wallets to store and manage funds
   - Add transactions to the mempool with sender, receiver, and amount
   - Mine new blocks (which will include all pending transactions)
   - View the contents of the blockchain
   - View pending transactions in the mempool
   - View details of a specific block
   - Change the mining difficulty
   - Validate the integrity of the blockchain

## How It Works

1. Each block contains:
   - Block number
   - Timestamp
   - Transactions (with sender, receiver, and amount)
   - Previous block's hash
   - Current block's hash
   - Nonce (used for mining)

2. Mining a block:
   - The miner attempts to find a hash with a specific number of leading zeros (difficulty)
   - This is done by incrementing the nonce and recalculating the hash until a valid hash is found
   - Once found, the block is added to the blockchain

3. Transactions:
   - Each transaction includes a sender, receiver, and amount
   - Transactions are signed with the sender's private key
   - When a block is mined, the transactions are confirmed and balances are updated

4. Wallets:
   - Each wallet has a private key and public key
   - The public key is used as the wallet's address
   - Wallets track their balance based on sent and received transactions 